"""
Shared work experience handler logic.
"""
from shared.db import get_dynamodb_table

def get_work_experience():
    """
    Get work experience items sorted by date (most recent first).
    
    Returns:
        list: Work experience items
    """
    table = get_dynamodb_table()
    
    response = table.query(
        IndexName='TypeIndex',
        KeyConditionExpression='#t = :type',
        ExpressionAttributeNames={'#t': 'type'},
        ExpressionAttributeValues={':type': 'work_experience'}
    )
    
    items = response.get('Items', [])
    
    # Sort: current jobs first, then by start date descending
    items.sort(key=lambda x: (
        not x.get('is_current', False),
        x.get('start_date', '')
    ), reverse=True)
    
    return items
